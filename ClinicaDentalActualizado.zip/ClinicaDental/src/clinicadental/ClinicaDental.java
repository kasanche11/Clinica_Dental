

package clinicadental;

public class ClinicaDental {

    public static void main(String[] args) {
        Inicio ad = new Inicio();
        ad.setVisible(true);
    }
    
}
