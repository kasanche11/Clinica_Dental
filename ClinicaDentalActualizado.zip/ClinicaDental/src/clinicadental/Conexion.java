package clinicadental;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String USER = "CLINICA_DENTAL";
    private static final String PASSWORD = "CLINICADENTAL2024";
    
    public static Connection getConexion(){
        
        Connection con = null;
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver JDBC de Oracle.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos:");
            e.printStackTrace();
        }
        
        return con;
        
    }
    
}
