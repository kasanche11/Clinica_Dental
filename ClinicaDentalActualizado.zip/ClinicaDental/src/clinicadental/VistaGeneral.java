/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package clinicadental;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;



/**
 *
 * @author Usuario
 */
public class VistaGeneral extends javax.swing.JFrame {

 private DefaultTableModel modeloTabla;

    public VistaGeneral() {
        initComponents();
        configurarComponentes();
    }

    
    private void configurarComponentes() {
        // Inicializar el modelo de tabla
        modeloTabla = new DefaultTableModel();
        jTable1.setModel(modeloTabla);

        // Configurar los listeners de los botones para cargar las vistas correspondientes
        Detalles_Citas.addActionListener(e -> cargarVista("DETALLE_CITA"));
        Lista_Dentistas.addActionListener(e -> cargarVista("LISTA_DENTISTAS"));
        Pacientes_Ultima_Cita.addActionListener(e -> cargarVista("PACIENTES_ULTIMA_CITA"));
        Pacientes_Activos.addActionListener(e -> cargarVista("PACIENTES_ACTIVOS"));
        Vista_Historial_Paciente.addActionListener(e -> cargarVista("HISTORIAL_PACIENTE"));
    }

    private void cargarVista(String nombreVista) {
        // Limpiar el modelo de la tabla antes de cargar nuevos datos
        modeloTabla.setRowCount(0);
        modeloTabla.setColumnCount(0);

        // Consulta para obtener los datos de la vista
        String query = "SELECT * FROM " + nombreVista;

        try (Connection con = Conexion.getConexion(); // Obtener la conexión a la base de datos
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Configurar las columnas de la tabla basándose en el ResultSet
            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                modeloTabla.addColumn(rs.getMetaData().getColumnName(i));
            }

            // Agregar las filas al modelo
            while (rs.next()) {
                Object[] fila = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                modeloTabla.addRow(fila);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar los datos de la vista '" + nombreVista + "': " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

  
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Detalles_Citas = new javax.swing.JButton();
        Pacientes_Ultima_Cita = new javax.swing.JButton();
        Lista_Dentistas = new javax.swing.JButton();
        Vista_Historial_Paciente = new javax.swing.JButton();
        Pacientes_Activos = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Monotype Corsiva", 2, 36)); // NOI18N
        jLabel1.setText("Vistas");

        jButton2.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        jButton2.setText("X");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        Detalles_Citas.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        Detalles_Citas.setText("Detalles Citas");
        Detalles_Citas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Detalles_CitasActionPerformed(evt);
            }
        });

        Pacientes_Ultima_Cita.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        Pacientes_Ultima_Cita.setText("Ultima Cita");
        Pacientes_Ultima_Cita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Pacientes_Ultima_CitaActionPerformed(evt);
            }
        });

        Lista_Dentistas.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        Lista_Dentistas.setText("Dentistas");
        Lista_Dentistas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Lista_DentistasActionPerformed(evt);
            }
        });

        Vista_Historial_Paciente.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        Vista_Historial_Paciente.setText("Historial");
        Vista_Historial_Paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Vista_Historial_PacienteActionPerformed(evt);
            }
        });

        Pacientes_Activos.setFont(new java.awt.Font("Monotype Corsiva", 2, 24)); // NOI18N
        Pacientes_Activos.setText("Pacientes");
        Pacientes_Activos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Pacientes_ActivosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(49, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Pacientes_Activos, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Vista_Historial_Paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Lista_Dentistas, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pacientes_Ultima_Cita, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Detalles_Citas, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(Detalles_Citas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Lista_Dentistas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Pacientes_Activos, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(Pacientes_Ultima_Cita, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Vista_Historial_Paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 823, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jButton2))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Detalles_CitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Detalles_CitasActionPerformed
       int ID;
        try {
            ID = Integer.parseInt(txtID.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID válido.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
            return;
        }

        txtResultado.setText(""); // Limpiar JTextArea antes de mostrar resultados

        try (Connection con = Conexion.getConexion()) {
            // Llamar a la función Oracle
            CallableStatement cs = con.prepareCall("{ ? = call ObtenerInfoDentista(?) }");

            // Registrar el parámetro de salida
            cs.registerOutParameter(1, java.sql.Types.VARCHAR);

            // Configurar el parámetro de entrada
            cs.setInt(2, ID);

            // Ejecutar la función
            cs.execute();

            // Obtener el resultado
            String resultado = cs.getString(1);

            if (resultado != null) {
                txtResultado.setText(resultado); // Mostrar el resultado en el JTextArea
            } else {
                txtResultado.setText("No se encontró un dentista con el ID proporcionado.");
            }

            cs.close();

        } catch (SQLException e) {
            
        }
        
        
    }//GEN-LAST:event_Detalles_CitasActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Inicio n = new Inicio();

        n.setVisible(true);

        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void Pacientes_Ultima_CitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Pacientes_Ultima_CitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Pacientes_Ultima_CitaActionPerformed

    private void Lista_DentistasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Lista_DentistasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Lista_DentistasActionPerformed

    private void Vista_Historial_PacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Vista_Historial_PacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Vista_Historial_PacienteActionPerformed

    private void Pacientes_ActivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Pacientes_ActivosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Pacientes_ActivosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaGeneral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaGeneral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaGeneral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaGeneral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaGeneral().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Detalles_Citas;
    private javax.swing.JButton Lista_Dentistas;
    private javax.swing.JButton Pacientes_Activos;
    private javax.swing.JButton Pacientes_Ultima_Cita;
    private javax.swing.JButton Vista_Historial_Paciente;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
